package com.emids.health;

public class InsuranceExpectedResult {
	
	public String getName() {
		return "Ramcharan";
	}

	
	
}
