package com.emids.health;

public class CheckEligibility implements CheckPerson {

	public int isHypertension(Person p, int basePremium) {
		return basePremium * 1 / 100;
	}

	@Override
	public int getHypertensionPercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 1 / 100;
	}

	@Override
	public int getBloodPressurePercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 1 / 100;
	}

	@Override
	public int getBloodSugarPercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 1 / 100;
	}

	@Override
	public int getOverweightPercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 1 / 100;
	}

	@Override
	public int getSmokingPercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 3 / 100;
	}

	@Override
	public int getAlcoholPercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 3 / 100;
	}

	@Override
	public int getDailyExercisePercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 3 / 100;
	}

	@Override
	public int getDrugsPercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 3 / 100;
	}

	@Override
	public int getMalePercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 2 / 100;
	}

	@Override
	public int getFemalePercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 2 / 100;
	}

	@Override
	public int getOtherPercent(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 2 / 100;
	}

	@Override
	public int getBelow18(int basePremium) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int get18and25(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 10 / 100;
	}

	@Override
	public int get25and30(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 10 / 100;
	}

	@Override
	public int get30and35(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 10 / 100;
	}

	@Override
	public int get35and40(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 10 / 100;
	}

	@Override
	public int getAbove40(int basePremium) {
		// TODO Auto-generated method stub
		return basePremium * 20 / 100;
	}

	@Override
	public double getPersonAgePremiumAmount(Person p, int basePremium) {
		if (p.getAge() < 18) {
			p.AgePremiumAmount = getBelow18(basePremium);
		} else if (p.getAge() >= 18 && p.getAge() <= 25) {
			p.AgePremiumAmount = get18and25(basePremium);
		} else if (p.getAge() >= 25 && p.getAge() <= 30) {
			p.AgePremiumAmount = get25and30(basePremium);
		} else if (p.getAge() >= 30 && p.getAge() <= 35) {
			p.AgePremiumAmount = get30and35(basePremium);
		} else if (p.getAge() >= 30 && p.getAge() <= 35) {
			p.AgePremiumAmount = get35and40(basePremium);
		} else {
			p.AgePremiumAmount = getAbove40(basePremium);
		}
		System.out
				.println("Age Premium Amount : INCREASE (18-25 -> + 10% | 25-30 -> +10% | 30-35 -> +10% | 35-40 -> +10% | 40+ -> 20% )"
						+ p.AgePremiumAmount);
		return p.AgePremiumAmount;
	}

	@Override
	public double getPersonGenderPremiumAmount(Person p, int basePremium) {

		if (p.gender.getCode() == 1) {
			p.GenderPremiumAmount = basePremium * 2 / 100;
		}
		System.out.println("Gender Premium Amount : (Increase 2%) "
				+ p.GenderPremiumAmount);
		return p.GenderPremiumAmount;
	}

	@Override
	public double getPersonHealthPremiumAmount(Person p, int basePremium) {
		if (p.isHyperTension()) {
			p.healthPremiumAmount += getHypertensionPercent(basePremium);
		}
		if (p.isBloodPressure()) {
			p.healthPremiumAmount += getBloodPressurePercent(basePremium);
		}
		if (p.isBloodSugar()) {
			p.healthPremiumAmount += getBloodSugarPercent(basePremium);
		}
		if (p.isOverWeight()) {
			p.healthPremiumAmount += getOverweightPercent(basePremium);
		}
		System.out
				.println("Health Premium Amount : (Hypertension | Blook pressure | Blood sugar | Overweight Increase of 1% per condition)  "
						+ p.healthPremiumAmount);
		return p.healthPremiumAmount;
	}

	@Override
	public double getPersonHabitsPremiumAmount(Person p, int basePremium) {
		if (p.isSmoking()) {
			p.habitsPremiumAmount += getSmokingPercent(basePremium);
		}
		if (p.isAlcohol()) {
			p.habitsPremiumAmount += getAlcoholPercent(basePremium);
		}
		if (p.isExcercise()) {
			p.habitsPremiumAmount -= getDailyExercisePercent(basePremium);
		}
		if (p.isDrugs()) {
			p.habitsPremiumAmount += getDrugsPercent(basePremium);
		}
		System.out
				.println("Habits Premium Amount : (Daily exercise) -> Reduce 3% -> (Smoking | Consumption of alcohol | Drugs) -> Increase 3% "
						+ p.habitsPremiumAmount);
		return p.habitsPremiumAmount;
	}
}
